# Wavelet-YOLO-GAT Pipeline
